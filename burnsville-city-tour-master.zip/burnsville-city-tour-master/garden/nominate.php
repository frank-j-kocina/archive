<?php
   // did files get sent
   if(isset($_FILES) && (bool) $_FILES) {
   
      // define allowed extensions
      $allowedExtensions = array("","gif","jpeg","jpg","png","bmp","GIF","JPEG","JPG","PNG","BMP");
      $files = array();
         
      // loop through all the files
      foreach($_FILES as $name=>$file) {
        // define some variables
        $file_name = $file['name']; 
        $temp_name = $file['tmp_name'];
          
        if (strlen($file_name) > 0) {
          // check if this file type is allowed
          $path_parts = pathinfo($file_name);
          $ext = $path_parts['extension'];
          if(!in_array($ext,$allowedExtensions)) {
            die("Sorry, you have attached an invalid file type. <a href='http://burnsvillecitytour.com'>Click here</a> to return to burnsvillecitytour.com</p>");
          }
          
          // move this file to the server YOU HAVE TO DO THIS
          $server_file = "/home/content/28/9180228/html/uploads/$path_parts[basename]";
          move_uploaded_file($temp_name,$server_file);
          
          // add this file to the array of files
          array_push($files,$server_file);
        }
      }  

      // other one =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      $nomineeName = $_POST['nomineeName'];
      $nomineePhone = $_POST['nomineePhone'];
      $nomineeAddress = $_POST['nomineeAddress'];
      $nomineeNeighborhood = $_POST['nomineeNeighborhood'];
      $nomineePropertyOwner = $_POST['nomineePropertyOwner'];
      $nomineePropertyType = $_POST['nomineePropertyType'];
      
      $nominatorName = $_POST['nominatorName'];
      $nominatorPhone = $_POST['nominatorPhone'];
      $nominatorAddress = $_POST['nominatorAddress'];
      $nominatorEmailAddress = $_POST['nominatorEmailAddress'];
      
      $comments = $_POST['comments'];
      // other one =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

      // define some mail variables
      $to = "info@burnsvillemn.com";
      $from = $nominatorAddress;
      $subject ="Garden Nomination";
      $msg = "Garden Contest Entry:\n\n\n";
      $headers = "From: $from";
      
      $msg .= "Nominee Information:\n\n";
      $msg .= "Name: " . $nomineeName . "\n";
      $msg .= "Phone: " . $nomineePhone . "\n";
      $msg .= "Address: " . $nomineeAddress . "\n";
      $msg .= "Neighborhood: " . $nomineeNeighborhood . "\n";
      $msg .= "Property Owner: " . $nomineePropertyOwner . "\n";
      $msg .= "Property Type: " . $nomineePropertyType . "\n\n";
      
      $msg .= "Nominator Information:\n\n";
      $msg .= "Name: " . $nominatorName . "\n";
      $msg .= "Phone: " . $nominatorPhone . "\n";
      $msg .= "Address: " . $nominatorAddress . "\n";
      $msg .= "Email Address: " . $nominatorEmailAddress . "\n\n";
      
      $msg .= "Comments: " . $comments . "\n";
      
      // define our boundary
      $semi_rand = md5(time()); 
      $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
      
      // tell the header about the boundary
      $headers .= "\nMIME-Version: 1.0\n";
      $headers .= "Content-Type: multipart/mixed;\n";
      $headers .= " boundary=\"{$mime_boundary}\""; 
      
      // part 1: define the plain text email
      $message ="\n\n--{$mime_boundary}\n";
      $message .="Content-Type: text/plain; charset=\"iso-8859-1\"\n";
      $message .="Content-Transfer-Encoding: 7bit\n\n" . $msg . "\n\n";
      $message .= "--{$mime_boundary}\n";
      
      // part 2: loop and define mail attachments
      foreach($files as $file) {
         $aFile = fopen($file,"rb");
         $data = fread($aFile,filesize($file));
         fclose($aFile);
         $data = chunk_split(base64_encode($data));
         $message .= "Content-Type: {\"application/octet-stream\"};\n";
         $message .= " name=\"$file\"\n";
         $message .= "Content-Disposition: attachment;\n";
         $message .= " filename=\"$file\"\n";
         $message .= "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
         $message .= "--{$mime_boundary}\n";
      }
   
      // send the email
      $ok = mail($to, $subject, $message, $headers); 
      if ($ok) { 
         echo "<p>Mail sent to $to! <a href='http://burnsvillecitytour.com'>Click here</a> to return to burnsvillecitytour.com</p>";
      } else { 
         echo "<p>We're sorry, there was an error and your mail was not sent. <a href='http://burnsvillecitytour.com'>Click here</a> to return to burnsvillecitytour.com</p>";
      }
      die();
   }
?>