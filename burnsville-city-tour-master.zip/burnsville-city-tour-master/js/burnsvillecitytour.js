$(document).ready(function() {
  var contentHeight = $("#content").height();
  var sidebarHeight = $("#sidebar").height();
  if(contentHeight > sidebarHeight) {
    $("#sidebar").height(contentHeight);
  } else {
    $("#content").height(sidebarHeight);
  }

  $("#lighting").on("click", function() {
  	window.location = "lighting/contestInfo.html";
  });
  $("#garden").on("click", function() {
  	window.location = "garden/contestInfo.html";
  });

  //window.setTimeout(pulse, 1000);
});

function pulse() {
  window.setTimeout(function() {
    $("#lighting").css("margin-top", "-1px");
    $("#lighting").css("margin-left", "-1px");
    $("#lighting").css("border", "3px solid #eeeeee");
    $("#spacer").css("width", "19px");
  }, 100);
  window.setTimeout(function() {
    $("#lighting").css("margin-top", "-2px");
    $("#lighting").css("margin-left", "-2px");
    $("#lighting").css("border", "4px solid #eeeeee");
    $("#spacer").css("width", "18px");
  }, 200);
  window.setTimeout(function() {
    $("#lighting").css("margin-top", "-1px");
    $("#lighting").css("margin-left", "-1px");
    $("#lighting").css("border", "3px solid #eeeeee");
    $("#spacer").css("width", "19px");
  }, 300);
  window.setTimeout(function() {
    $("#lighting").css("margin-top", "0");
    $("#lighting").css("margin-left", "0");
    $("#lighting").css("border", "2px solid #eeeeee");
    $("#spacer").css("width", "20px");
  }, 400);
  window.setTimeout(pulse, 3000);
}

// TODO - implement with pure CSS
