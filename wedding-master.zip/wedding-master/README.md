Wedding
=======

The information and RSVP website for Frank "Joe" Kocina and Michelle Rock.

The front end of the website utilizes [HTML5](http://www.w3.org/TR/html5/), [CSS3](http://www.w3.org/Style/CSS/), and [JQuery](http://jquery.com/).

The back end of the website utilizes [Groovy](http://groovy.codehaus.org/), [Redis](http://redis.io/), and [Ratpack](http://ratpack.io/).
