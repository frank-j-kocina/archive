@Grapes([
    @Grab('redis.clients:jedis:2.2.1'),
    @GrabConfig(systemClassLoader = true)
])

import static src.Constants.*
import redis.clients.jedis.Jedis
import java.security.MessageDigest

Jedis getRedis() {
    new Jedis('localhost')
}

String generateSha256(String s) {
    String SALT = 'wedding'
    MessageDigest digest = MessageDigest.getInstance('SHA-256')
    digest.update((SALT + s).bytes);
    new BigInteger(1, digest.digest()).toString(16).padLeft(32, '0')
}

String getShortSha256(String s) {
    generateSha256(s).toLowerCase().substring(0, 8)
}

Boolean insertAttendee(String hashValue, Map attendee) {
    String REDIS_BASE = 'wedding'
    String SEPARATOR = ':'
    String ATTENDEES = 'attendees'

    String inviteListKey = REDIS_BASE + SEPARATOR + ATTENDEES
    String inviteKey = inviteListKey + SEPARATOR + hashValue
    String attendeeKey = inviteKey + SEPARATOR + "${attendee.name}${attendee.id}"

    if (!attendee.name)
        attendeeKey += "-${attendee.order}"

    redis.sadd(inviteListKey, inviteKey)
    redis.sadd(inviteKey, attendeeKey)
    redis.hmset(attendeeKey, attendee)

    return true
}

void execute() {
    String hash = null
    List<String> splitLine = null
    Boolean newGroup = true
    String filePath = "${baseDirectory}/import.csv"

    new File(filePath).eachLine { String line ->
        if (!newGroup && line.trim() == "") {
            hash = null
            newGroup = true
            return
        }

        if (newGroup) {
            splitLine = line.split(',')
            hash = getShortSha256(splitLine[0] + splitLine[2])
            newGroup = false
        }

        if (!newGroup) {
            splitLine = line.split(',')
            String name = splitLine[1] ? "${splitLine[1]} ${splitLine[2]}" : ''

            attendee = [id: splitLine[0], lastName: splitLine[2], name: name, attending: 'unknown', email: 'unknown',
                        song: 'unknown', special: 'unknown', order: splitLine[3]]
            insertAttendee(hash, attendee)
        }
    }

    println 'done'
}


execute()
