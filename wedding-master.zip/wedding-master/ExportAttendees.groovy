@Grapes([
    @Grab('redis.clients:jedis:2.2.1'),
    @GrabConfig(systemClassLoader = true)
])

import static src.Constants.*
import javax.mail.Message
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMultipart
import javax.activation.FileDataSource
import javax.activation.DataSource
import javax.activation.DataHandler
import redis.clients.jedis.Jedis

Jedis getRedis() {
    new Jedis('localhost')
}

Properties getEmailProperties() {
    Properties gmailProperties = System.properties
    gmailProperties.put('mail.smtp.port', '587')
    gmailProperties.put('mail.smtp.auth', 'true')
    gmailProperties.put('mail.smtp.starttls.enable', 'true')
    gmailProperties
}

MimeMessage createEmail(Session session) {
    MimeMessage email = new MimeMessage(session)

    InternetAddress address = new InternetAddress("kocinawedding@gmail.com")
    email.addRecipient(Message.RecipientType.TO, address)

    MimeBodyPart messageBodyPart = new MimeBodyPart()
    messageBodyPart.setText("Guest List")
    MimeMultipart multipart = new MimeMultipart()
    multipart.addBodyPart(messageBodyPart)

    messageBodyPart = new MimeBodyPart()
    String filePath = "${baseDirectory}/export.csv"
    DataSource source = new FileDataSource(filePath);
    messageBodyPart.setDataHandler(new DataHandler(source));
    messageBodyPart.setFileName("GuestList.csv");
    multipart.addBodyPart(messageBodyPart);

    email.setSubject("Kocina Wedding RSVP List")
    email.setContent(multipart);

    email
}

void sendEmail() {
    String host = "smtp.gmail.com"
    String fromGmailUser = "kocinawedding"
    String passwordFilePath = "${baseDirectory}/emailpwd.txt"
    String fromGmailPassword = new File(passwordFilePath).readLines().first()

    Session session = Session.getDefaultInstance(emailProperties, null)
    MimeMessage email = createEmail(session)
    Transport transport = session.getTransport("smtp")
    transport.connect(host, fromGmailUser, fromGmailPassword)
    transport.sendMessage(email, email.allRecipients)
    transport.close()
}

void execute() {
    String filePath = "${baseDirectory}/export.csv"
    String REDIS_BASE = 'wedding'
    String SEPARATOR = ':'
    String ATTENDEES = 'attendees'

    new File(filePath).withWriter { out ->
        out.writeLine("lastName,code,name,attending,email,song,special")
        out.writeLine("")

        String attendeesKey = REDIS_BASE + SEPARATOR + ATTENDEES
        Set attendeeCodeKeys = redis.smembers(attendeesKey)

        attendeeCodeKeys.each { String attendeeCodeKey ->
            String code = attendeeCodeKey - "${attendeesKey + SEPARATOR}"
            Set attendeeKeys = redis.smembers(attendeeCodeKey)

            List attendees = attendeeKeys.collect { redis.hgetAll(it) }
            attendees.sort { it.order }.each { Map attendee ->
                String line = attendee.lastName + ',' + code + ',' + attendee.name + ',' + attendee.attending +
                        ',' + attendee.email + ',' + attendee.song + ',' + attendee.special
                out.writeLine(line)
            }

            out.writeLine("")
        }
    }

    if (environment == PRODUCTION)
        sendEmail()

    println 'done'
}

execute()