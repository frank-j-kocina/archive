package src

class Constants {

    static final String DEVELOPMENT = 'development'
    static final String PRODUCTION = 'production'

    static String getEnvironment() {
        System.getenv().get('USER').toString() == 'fkocina' ? DEVELOPMENT : PRODUCTION
    }

    static String getBaseDirectory() {
        environment == DEVELOPMENT ? '/Users/fkocina/dev/wedding' : '/home/ec2-user/wedding'
    }
}
