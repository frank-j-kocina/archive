package src

import static src.Constants.*
import javax.mail.Message
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

public class EmailConfirmationService {

    private static MimeMessage createEmail(String body, List<String> recipients, Session session) {
        MimeMessage email = new MimeMessage(session)

        recipients.each { String recipient ->
            if (recipient) {
                InternetAddress address = new InternetAddress(recipient)
                email.addRecipient(Message.RecipientType.TO, address)
            }
        }

        InternetAddress bcc = new InternetAddress("kocinawedding@gmail.com")
        email.addRecipient(Message.RecipientType.BCC, bcc)

        email.setSubject("Kocina Wedding RSVP Confirmation");
        email.setContent(body, "text/html")

        email
    }

    public static void sendConfirmationEmail(String body, List<String> recipients) {
        String host = "smtp.gmail.com"
        String fromGmailUser = "kocinawedding"
        String passwordFilePath = "${baseDirectory}/emailpwd.txt"
        String fromGmailPassword = new File(passwordFilePath).readLines().first()

        Session session = Session.getDefaultInstance(emailProperties, null)
        MimeMessage email = createEmail(body, recipients, session)

        Transport transport = session.getTransport("smtp")
        transport.connect(host, fromGmailUser, fromGmailPassword)
        transport.sendMessage(email, email.allRecipients)
        transport.close()
    }

    private static Properties getEmailProperties() {
        Properties gmailProperties = System.properties
        gmailProperties.put('mail.smtp.port', '587')
        gmailProperties.put('mail.smtp.auth', 'true')
        gmailProperties.put('mail.smtp.starttls.enable', 'true')
        gmailProperties
    }
}