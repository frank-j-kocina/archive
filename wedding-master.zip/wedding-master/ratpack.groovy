@Grapes([
    @Grab("io.ratpack:ratpack-groovy:0.9.0"),
    @Grab('redis.clients:jedis:2.2.1'),
    @GrabConfig(systemClassLoader = true)
])

import static ratpack.groovy.Groovy.*
import static groovy.json.JsonOutput.toJson
import static src.Constants.*
import groovy.text.SimpleTemplateEngine
import groovy.json.JsonSlurper
import redis.clients.jedis.Jedis
import src.EmailConfirmationService

void log (String message) {
    new File("${baseDirectory}/log.txt").append(message + '\n')
}

void updateRsvps(Map requestDataMap) {
    String REDIS_BASE = 'wedding'
    String SEPARATOR = ':'
    String ATTENDEES = 'attendees'

    Jedis redis = new Jedis('localhost')
    String accessCodeKey = REDIS_BASE + SEPARATOR + ATTENDEES + SEPARATOR + requestDataMap.accessCode
    Set accessCodeMembers = redis.smembers(accessCodeKey)

    if (!accessCodeMembers)
        throw new Exception("not found")

    List<Map> attendees = accessCodeMembers.collect { String attendeeKey ->
        [key: attendeeKey, value: redis.hgetAll(attendeeKey)]
    }.sort { it.value.order }

    attendees.eachWithIndex { Map attendeeMap, Integer index ->
        String attendeeKey = attendeeMap.key
        Map attendee = attendeeMap.value

        if (requestDataMap.names[index] == 'null')
            return

        if (!attendee.name)
            attendee.name = requestDataMap.names[index]

        if (requestDataMap.radios[index] == "true") {
            attendee.attending = "yes"
        } else if (requestDataMap.radios[index] == "false") {
            attendee.attending = "no"
        }

        attendee.email = requestDataMap.email

        if (requestDataMap.song)
            attendee.song = requestDataMap.song

        if (requestDataMap.special)
            attendee.special = requestDataMap.special

        try {
            redis.hmset(attendeeKey, attendee)
        } catch (Exception e) {
            log(e.message)
        }
    }
}

ratpack {
    handlers {
        get {
            render groovyTemplate("index.html")
        }

        post("rsvpAccess") {
            Map result = [:]

            try {
                String requestData = getRequest().text.toString()
                Map requestDataMap = new JsonSlurper().parseText(requestData)

                String REDIS_BASE = 'wedding'
                String SEPARATOR = ':'
                String ATTENDEES = 'attendees'

                Jedis redis = new Jedis('localhost')
                String accessCodeKey = REDIS_BASE + SEPARATOR + ATTENDEES + SEPARATOR + requestDataMap.accessCode.toLowerCase()
                Set accessCodeMembers = redis.smembers(accessCodeKey)

                if (!accessCodeMembers) {
                    log("NOT FOUND - access code: ${requestDataMap.accessCode}, last name: ${requestDataMap.lastName}")
                    response.send toJson([result: 'not found'])
                    return
                }

                List<Map> attendeeData = accessCodeMembers.collect { String attendeeKey ->
                    redis.hgetAll(attendeeKey)
                }.sort { it.order }

                String lastName = attendeeData.iterator().next().lastName

                if (!lastName.equalsIgnoreCase(requestDataMap.lastName)) {
                    log("NOT FOUND - access code: ${requestDataMap.accessCode}, last name: ${requestDataMap.lastName}")
                    response.send toJson([result: 'not found'])
                    return
                }

                result.result = "success"
                result.accessCode = requestDataMap.accessCode
                result.names = attendeeData.collect { it.name }

                response.send toJson(result)
            } catch (Exception exception) {
                log(exception.message)
                response.send toJson([result: 'failure'])
            }
        }

        post("rsvp") {
            try {
                String requestData = getRequest().text.toString()
                Map requestDataMap = new JsonSlurper().parseText(requestData)

                updateRsvps(requestDataMap)

                List rsvps = []
                Integer rsvpCount = requestDataMap.names.findAll { it != "null" }.size()

                (0..rsvpCount).each {
                    String name = requestDataMap.names[it]
                    Boolean attending = !(requestDataMap.radios[it].toString() == "false")

                    if (name != null && attending != null) {
                        rsvps << [name: name, attending: attending]
                    }
                }

                Thread.start {
                    SimpleTemplateEngine engine = new SimpleTemplateEngine()
                    File html = new File("${baseDirectory}/templates/rsvpConfirmation.html")
                    template = engine.createTemplate(html).make([model: [rsvps: rsvps]])
                    String body = template.toString()
                    EmailConfirmationService.sendConfirmationEmail(body, [requestDataMap.email])
                }

                response.send toJson([result: 'success'])
            } catch (Exception exception) {
                log(exception.message)
                response.send toJson([result: 'failure'])
            }
        }

        assets "public"
    }
}
