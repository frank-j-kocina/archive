$(document).ready(function () {
    var tabAnimating = false;

    $("#everything").hide();
    $("#long-story").hide();
    $(".tab-content").hide();
    $(".landing-content").show();

    $("#our-story-content").imagesLoaded(function() {
        $("#spinner").hide();
        $("#everything").fadeIn(500);
    });

    $("#show-long-story").on("click", function () {
        $("#short-story").fadeOut(500, function () {
            $("#long-story").fadeIn(500);
        });
    });

    $("#show-short-story").on("click", function () {
        $("#long-story").fadeOut(500, function () {
            $("#short-story").fadeIn(500);
        });
    });

    $(".nav-item").on("click", function () {
        if (tabAnimating === false) {
            tabAnimating = true;
            var newNavItem = this;
            var oldNavItem = $(".active-nav").first();
            var oldContentTabId = "#" + $(oldNavItem).attr("id") + "-content";
            var newContentTabId = "#" + $(this).attr("id") + "-content";
            var tabIdToFade = oldContentTabId;

            if ($("#rsvp-form-content").is(":visible"))
                tabIdToFade = "#rsvp-form-content";

            $(tabIdToFade).fadeOut(500, function () {
                oldNavItem.removeClass("active-nav");
                $(newNavItem).addClass("active-nav");

                $(newContentTabId).fadeIn(500, function () {
                    tabAnimating = false;
                });
            });
        }
    });

    $("#rsvp-access").on("click", function() {
        $("#rsvp-access-last-name").focus();
    });

    $("#rsvp-access-code, #rsvp-access-last-name").on("keyup", function(event) {
        if (event.which === 13)
            $("#rsvp-access-submit").trigger("click");
    });

    $("#rsvp-access-submit").on("click", function () {
        $("#rsvp-access-error").html("&nbsp;");
        $("#rsvp-access-last-name").removeClass("error");
        $("#rsvp-access-code").removeClass("error");
        $(this).attr("disabled", "disabled");

        var rsvpError = false;
        var lastName = $("#rsvp-access-last-name").val();
        var accessCode = $("#rsvp-access-code").val();

        if (!lastName) {
            $("#rsvp-access-error").append("<p>Please enter your last name.</p>");
            $("#rsvp-access-last-name").addClass("error");
            rsvpError = true;
        }

        if (!accessCode) {
            $("#rsvp-access-error").append("<p>Please enter the access code from your invitation.</p>");
            $("#rsvp-access-code").addClass("error");
            rsvpError = true;
        }

        if (!rsvpError) {
            var rsvpData = JSON.stringify({
                lastName: lastName,
                accessCode: accessCode
            });

            submitRsvpAccess(rsvpData);
        }

        $(this).removeAttr("disabled");
    });

    $("#rsvp-form-submit").on("click", function () {
        var rsvpData = getRsvpData();
        var rsvpError = false;

        $("#rsvp-form-error").html("&nbsp;");
        $(this).attr("disabled", "disabled");

        var attendees = $(".rsvp-form-name").length;
        var radios = 0;

        $.each(rsvpData.radios, function(index, radio) {
            if (radio != undefined)
                radios++;
        });

        if (radios != attendees) {
            $("#rsvp-form-error").append("<p>Please check attending or not attending for each guest.</p>");
            rsvpError = true;
        }

        if (!rsvpError) {
            if (rsvpData.email == "") {
                if(confirm("Are you sure you want to submit your RSVP without a confirmation email address?"))
                    submitRsvpForm(JSON.stringify(rsvpData));
            } else {
                submitRsvpForm(JSON.stringify(rsvpData));
            }
        }

        $(this).removeAttr("disabled");
    });
});

function submitRsvpAccess(rsvpData) {
    $.ajax({
        type: "POST",
        url: "rsvpAccess",
        data: rsvpData
    }).done(function (data) {
            var json = $.parseJSON(data);
            var result = json.result;
            if (result == "success") {
                $("#rsvp-access-last-name").val("");
                $("#rsvp-access-code").val("");
                showRsvpForm(json);
            } else if (result == "not found") {
                renderRsvpAccessError("Sorry, we could not find a matching last name and rsvp code in our system. Please check your access code and spelling. If you believe this is an error, please contact Joe at 952-237-1814.");
            } else if (result == "already rsvpd") {
                renderRsvpAccessError("We've already got your RSVP. If you need to change your RSVP details, please contact Joe at 952-237-1814.");
            } else if (result == "failure") {
                renderRsvpAccessError("Sorry, we've encountered a server error. Please try again later. If the problem persists, please contact Joe at 952-237-1814.");
            }
        }).fail(function () {
            renderRsvpAccessError("Sorry, we've encountered a server error. Please try again later. If the problem persists, please contact Joe at 952-237-1814.");
        });
}

function showRsvpForm(json) {
    var rsvpForm = buildRsvpForm(json);
    $("#rsvp-form-names").html(rsvpForm);

    $("#rsvp-access-content").fadeOut(500, function () {
        $("#rsvp-form-content").fadeIn(500);
    });
}

function renderRsvpAccessError(message) {
    $("#rsvp-access-error").html("");
    $("#rsvp-access-error").append("<div>" + message + "</div>");
}

function buildRsvpForm(json) {
    var namesHtml = "<input type='hidden' id='access-code' value='" + json.accessCode + "'>";
    var namesSize = json.names.length;

    for (var nameIndex = 0; nameIndex < namesSize; nameIndex++) {
        var name = json.names[nameIndex];
        if (name != "") {
            namesHtml += "<div>" + "<span class='rsvp-form-input'>" + "<input id='rsvp-form-name" + nameIndex + "' class='rsvp-form-name' type='text' disabled='disabled' value='" + name + "'/></span>";
        } else {
            namesHtml += "<div>" + "<span class='rsvp-form-input'>" + "<input id='rsvp-form-name" + nameIndex + "' class='rsvp-form-name plus-one' type='text' placeholder='Guest'/>" + "</span>";
        }

        namesHtml += " ( will <input type='radio' value='true' id='rsvp-form-radio" + nameIndex + "' name='name" + nameIndex + "'/> )" +
            " ( will not <input type='radio' value='false' id='rsvp-form-radio" + nameIndex + "' name='name" + nameIndex + "'/> )" +
            " be attending.</div>";
    }

    return namesHtml;
}

function submitRsvpForm(rsvpData) {
    $.ajax({
        type: "POST",
        url: "rsvp",
        data: rsvpData
    }).done(function (data) {
            var json = $.parseJSON(data);
            var result = json.result;
            if (result == "success") {
                alert("Your RSVP has been submitted successfully. If you do not receive your confirmation, please contact Joe at 952-237-1814.");
                $("#rsvp-form-content").fadeOut(500);
            }
        }).fail(function () {
            alert("failure");
            return false;
        });
}

function getRsvpData() {
    return {
        accessCode: $("#access-code").val(),
        names: [
            $("#rsvp-form-name0").val(),
            $("#rsvp-form-name1").val(),
            $("#rsvp-form-name2").val(),
            $("#rsvp-form-name3").val(),
            $("#rsvp-form-name4").val(),
            $("#rsvp-form-name5").val()],
        radios: [
            $("#rsvp-form-radio0:checked").val(),
            $("#rsvp-form-radio1:checked").val(),
            $("#rsvp-form-radio2:checked").val(),
            $("#rsvp-form-radio3:checked").val(),
            $("#rsvp-form-radio4:checked").val(),
            $("#rsvp-form-radio5:checked").val()],
        email: $("#rsvp-form-email").val(),
        song: $("#rsvp-form-song-request").val(),
        special: $("#rsvp-form-special-request").val()
    };
}