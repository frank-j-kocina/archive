

@Grapes([
        @Grab('redis.clients:jedis:2.2.1'),
        @GrabConfig(systemClassLoader = true)
])

import redis.clients.jedis.Jedis

Jedis getRedis() {
    new Jedis('localhost')
}

void execute() {
    Set<String> keys = redis.keys('wedding:attendees:*')
    keys.each { redis.del(it) }
    println 'done'
}

execute()