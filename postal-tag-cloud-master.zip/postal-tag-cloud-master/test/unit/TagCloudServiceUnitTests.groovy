class TagCloudServiceUnitTests extends GroovyTestCase {

    def tagCloudService

    void setUp() {
        tagCloudService = new TagCloudService()
    }

    void testCountPostalCodesByState() {
        def rawXmlText = """
            <geonames>
                <code>
                    <postalcode>75462</postalcode>
                    <name>Paris</name>
                    <countryCode>US</countryCode>
                    <lat>33.68045</lat>
                    <lng>-95.49054</lng>
                    <adminCode1>TX</adminCode1>
                    <adminName1>Texas</adminName1>
                    <adminCode2>277</adminCode2>
                    <adminName2>Lamar</adminName2>
                    <adminCode3/>
                    <adminName3/>
                </code>
            </geonames>
        """

        def xmlParser = new XmlParser()
        def postalCodeData = xmlParser.parseText(rawXmlText)
        def stateData = tagCloudService.countPostalCodesByState(postalCodeData)

        assert stateData.size() == 1
        assert stateData."Texas" == 1
    }

    void testCalculateStateWeights() {
        def stateData = [
                "Minnesota": 25,
                "New York": 30,
                "California": 60,
                "Rhode Island": 3
        ]

        def weightedStates = tagCloudService.calculateStateWeights(stateData).sort { it.stateName }

        assert weightedStates.size() == 4
        assert weightedStates[0].stateName == "California"
        assert weightedStates[0].fontSize == 35
        assert weightedStates[1].stateName == "Minnesota"
        assert weightedStates[1].fontSize == 24
        assert weightedStates[2].stateName == "New York"
        assert weightedStates[2].fontSize == 25
        assert weightedStates[3].stateName == "Rhode Island"
        assert weightedStates[3].fontSize == 16
    }

    void testCalculateVariedStateWeights() {
        def stateData = [
                "Minnesota": 25,
                "New York": 30,
                "California": 60,
                "Rhode Island": 3
        ]

        def weightedStates = tagCloudService.calculateVariedStateWeights(stateData).sort { it.stateName }

        assert weightedStates.size() == 4
        assert weightedStates[0].stateName == "California"
        assert weightedStates[0].fontSize == 36
        assert weightedStates[1].stateName == "Minnesota"
        assert weightedStates[1].fontSize == 26
        assert weightedStates[2].stateName == "New York"
        assert weightedStates[2].fontSize == 31
        assert weightedStates[3].stateName == "Rhode Island"
        assert weightedStates[3].fontSize == 21
    }

    void testCalculateModularStateWeights() {
        def stateData = [
                "Minnesota": 25,
                "New York": 30,
                "California": 60,
                "Rhode Island": 3
        ]

        def weightedStates = tagCloudService.calculateModularStateWeights(stateData).sort { it.stateName }

        assert weightedStates.size() == 4
        assert weightedStates[0].stateName == "California"
        assert weightedStates[0].fontSize == 36
        assert weightedStates[1].stateName == "Minnesota"
        assert weightedStates[1].fontSize == 28
        assert weightedStates[2].stateName == "New York"
        assert weightedStates[2].fontSize == 36
        assert weightedStates[3].stateName == "Rhode Island"
        assert weightedStates[3].fontSize == 28
    }
}