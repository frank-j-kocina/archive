import static groovyx.net.http.ContentType.TEXT
import groovyx.net.http.HTTPBuilder
import redis.clients.jedis.Jedis

class TagCloudService {

    def redisService

    def retrievePostalCodeData() {
        def rawXmlText = null
        def http = new HTTPBuilder('http://api.geonames.org')
        def params = [placename: 'US', username: 'koci0019', maxRows: 500]

        http.get( path: '/postalCodeSearch',
                contentType: TEXT,
                query: params ) { def resp, def reader ->

            rawXmlText = reader.readLines().join()
        }

        def xmlParser = new XmlParser()
        def postalCodeData = xmlParser.parseText(rawXmlText)
        postalCodeData = postalCodeData.value().findAll { it.name() == "code" }

        return postalCodeData
    }

    def countPostalCodesByState(def postalCodeData) {
        def stateData = [:]

        postalCodeData.each { def postalCode ->
            def stateName = postalCode.value().find {
                it.name() == "adminName1"
            }.value()[0]

            if (stateData."${stateName}") {
                stateData."${stateName}" += 1
            } else {
                stateData."${stateName}" = 1
            }
        }

        return stateData
    }

    def calculateStateWeights(def stateData) {
        def stateList = stateData.collect { def stateName, def postalCodeCount ->
            [stateName: stateName, postalCodeCount: postalCodeCount]
        }

        def maxCount = stateList.max { it.postalCodeCount }.postalCodeCount
        def maxFontSize = 36
        def minFontSize = 16
        def maxSizeDifference = maxFontSize - minFontSize
        def fontRatio = maxSizeDifference / maxCount

        def weightedStateData = stateData.collect { def stateName, def postalCodeCount ->
            def fontSize = (minFontSize + (postalCodeCount * fontRatio)).toInteger()
            [stateName: stateName, fontSize: fontSize]
        }

        return weightedStateData
    }

    def calculateVariedStateWeights(def stateData) {
        def stateList = stateData.collect { def stateName, def postalCodeCount ->
            [stateName: stateName, postalCodeCount: postalCodeCount]
        }

        def maxFontSize = 36
        def minFontSize = 16
        def maxSizeDifference = maxFontSize - minFontSize
        def stateCount = stateList.size()
        def fontRatio = maxSizeDifference / stateCount

        def sortedStateList = stateList.sort { a, b -> b.postalCodeCount <=> a.postalCodeCount }
        def weightedStateData = sortedStateList.collect {
            def fontSize = (minFontSize + (stateCount-- * fontRatio)).toInteger()
            [stateName: it.stateName, fontSize: fontSize]
        }

        return weightedStateData
    }

    def calculateModularStateWeights(def stateData) {
        def stateList = stateData.collect { def stateName, def postalCodeCount ->
            [stateName: stateName, postalCodeCount: postalCodeCount]
        }

        def sortedStateList = stateList.sort { a, b -> b.postalCodeCount <=> a.postalCodeCount }
        def counter = 0

        def weightedStateData = sortedStateList.collect {
            def fontSize = 16
            if (counter < 2) {
                fontSize = 36
            } else if (counter < 5) {
                fontSize = 28
            } else if (counter < 12) {
                fontSize = 22
            }
            counter++
            [stateName: it.stateName, fontSize: fontSize]
        }

        return weightedStateData
    }

    def copyStateDataToRedis(def stateData) {
        stateData.each { def state ->
            redisService.withRedis { Jedis redis ->
                redis.set("postalTagCloud:state:${state.stateName}", state.fontSize.toString())
            }
        }
    }

    def clearStateDataFromRedis() {
        def redisStateKeys = null
        redisService.withRedis { Jedis redis ->
            redisStateKeys = redis.keys("postalTagCloud:state:*")
        }

        redisStateKeys.each { String redisStateKey ->
            redisService.withRedis { Jedis redis ->
                redis.del(redisStateKey.toString())
            }
        }
    }
}