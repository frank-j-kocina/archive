class UrlMappings {

    static mappings = {
        "/$controller/$action?/$id?" {
            constraints {
                // apply constraints here
            }
        }

        "/"(controller: "main", action: "index")
        "404"(controller: "main", action: "notFound")
        "500"(controller: "main", action: "error")
    }
}