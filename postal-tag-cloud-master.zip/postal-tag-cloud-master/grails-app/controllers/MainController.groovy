class MainController {

    def tagCloudService

    def index() {
        render(view: "index")
    }

    def states() {
        def postalCodeData = tagCloudService.retrievePostalCodeData()
        def stateCounts = tagCloudService.countPostalCodesByState(postalCodeData)
        def weightedStates = tagCloudService.calculateModularStateWeights(stateCounts)
        tagCloudService.copyStateDataToRedis(weightedStates)
        render(view: "states", model: [states: weightedStates.sort { it.stateName }])
    }

    def reset() {
        tagCloudService.clearStateDataFromRedis()
        redirect(action: "index")
    }

    def error() {
        render(view: "error")
    }

    def notFound() {
        render(view: "notFound")
    }
}