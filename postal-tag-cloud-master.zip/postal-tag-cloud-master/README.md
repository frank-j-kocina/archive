postal-tag-cloud
================

* In Groovy, use a public API to retrieve and store postal code information for all fifty US states.
* Generate a tag cloud of state names based on the number of postal codes per state.
* Sort the names in ascending alphabetical order.
* Provide a method for clearing the data and starting over.
* Use Github and create tests.
