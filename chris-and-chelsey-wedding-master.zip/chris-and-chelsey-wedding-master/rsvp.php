<?php
    // prevent timeout
    ob_start();
    set_time_limit(0);

    // grab html form elements
    $name1 = $_POST['name1'];
    $name2 = $_POST['name2'];
    $name3 = $_POST['name3'];
    $name4 = $_POST['name4'];
    $name5 = $_POST['name5'];
    $name6 = $_POST['name6'];
    $attending1 = ($_POST['attending1'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $attending2 = ($_POST['attending2'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $attending3 = ($_POST['attending3'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $attending4 = ($_POST['attending4'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $attending5 = ($_POST['attending5'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $attending6 = ($_POST['attending6'] == "yes") ? 'Accept with pleasure' : 'Decline with regret';
    $confirmEmail = $_POST['confirm-email'];

    // set mail headers
    $toEmail = "info@henney-barber-wedding.com";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/plain; charset='iso-8859-1'" . "\r\n";
    $headers .= $confirmEmail ? ("Cc: $confirmEmail" . "\r\n") : "";
    $headers .= "From: Chris and Chelsey <info@henney-barber-wedding.com>" . "\r\n";

    // build the message
    $subject = "Henney-Barber Wedding RSVP Confirmation";
    $message = "We have received the following RSVP details:\r\n\r\n";
    $message .= $name1 ? ($name1 . " - " . $attending1 . "\r\n") : "";
    $message .= $name2 ? ($name2 . " - " . $attending2 . "\r\n") : "";
    $message .= $name3 ? ($name3 . " - " . $attending3 . "\r\n") : "";
    $message .= $name4 ? ($name4 . " - " . $attending4 . "\r\n") : "";
    $message .= $name5 ? ($name5 . " - " . $attending5 . "\r\n") : "";
    $message .= $name6 ? ($name6 . " - " . $attending6 . "\r\n") : "";

    // send the email
    $ok = mail($toEmail, $subject, $message, $headers);

    if ($ok) {
       echo "<p>Thanks for your RSVP! You should receive a confirmation email shortly. <a href='http://henney-barber-wedding.com'>Return to henney-barber-wedding.com</a></p>";
    } else {
       echo "<p>We're sorry, there was an error and your mail was not sent. <a href='http://henney-barber-wedding.com'>Return to henney-barber-wedding.com</a></p>";
    }

    ob_flush();
    die();
?>