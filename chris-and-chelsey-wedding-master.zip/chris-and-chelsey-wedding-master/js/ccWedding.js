var rsvpRowCount = 4;

$(document).on("ready", function() {
    $(".content").addClass("hide");
    $("#our-story").removeClass("hide");
    $("#our-story-btn").addClass("btn-coral");
    $(".ccw-nav li").on("click", function(buttonClicked) {
        changePage(buttonClicked);
    });
    $("#addRsvpRow").on("click", addRsvpRow);
    $("#fpaddRsvpRow").on("click", fpaddRsvpRow);
    $("#submitRsvp").on("click", submitRsvp);
    $("#fpsubmitRsvp").on("click", fpsubmitRsvp);
    $("a[rel^='prettyPhoto']").prettyPhoto({social_tools: false, overlay_gallery: false, slideshow: 6000});
});

function changePage(buttonClicked) {
    var targetContent = buttonClicked.target.id.toString().replace("-btn", "");
    $(".content").addClass("hide");
    $(".ccw-nav li").removeClass("btn-coral");
    $("#" + targetContent).removeClass("hide");
    $("#" + targetContent + "-btn").addClass("btn-coral");
}

function addRsvpRow() {
    if (rsvpRowCount < 6) {
        rsvpRowCount++;
        var rsvpRow = [
            '<div class="rsvp-row clearfix">',
            '<div class="rsvp-column">',
                '<label for="name' + rsvpRowCount + '" class="rsvp-label">Name</label>',
                '<input type="text" class="rsvp-input" id="name' + rsvpRowCount + '" name="name' + rsvpRowCount + '"/>',
            '</div>',
            '<div class="rsvp-column">',
                '<label for="attending' + rsvpRowCount + '-yes" class="rsvp-label">Accept with pleasure</label>',
                '<input type="radio" class="rsvp-input" name="attending' + rsvpRowCount + '" id="attending' + rsvpRowCount + '-yes" value="yes" checked="checked"/>',
            '</div>',
            '<div class="rsvp-column">',
                '<label for="attending' + rsvpRowCount + '-no" class="rsvp-label">Decline with regret</label>',
                '<input type="radio" class="rsvp-input" name="attending' + rsvpRowCount + '" id="attending' + rsvpRowCount + '-no" value="no"/>',
            '</div>',
        '</div>'].join('');
        $(rsvpRow).insertBefore($("#rsvp-end"));
    } else if (rsvpRowCount == 6) {
        rsvpRowCount++;
        var contactChris = [
            '<div class="rsvp-row clearfix"></div>',
            '<p>Please contact Chris at (952) 484-5338 if your party contains more than six people. Thanks, and sorry for the inconvenience.</p>'
        ].join('');
        $(contactChris).insertBefore($("#rsvp-end"));
    } else {
        // do nothing
    }
}

function fpaddRsvpRow() {
    if (rsvpRowCount < 6) {
        rsvpRowCount++;
        var rsvpRow = [
            '<div class="rsvp-row clearfix">',
                '<div class="rsvp-column">',
                    '<label for="fpname' + rsvpRowCount + '" class="rsvp-label">Name</label>',
                    '<input type="text" class="rsvp-input" id="fpname' + rsvpRowCount + '" name="fpname' + rsvpRowCount + '"/>',
                '</div>',
                '<div class="rsvp-column">',
                    '<label for="fpattending' + rsvpRowCount + '-yes" class="rsvp-label">Accept with pleasure</label>',
                    '<input type="radio" class="rsvp-input" name="fpattending' + rsvpRowCount + '" id="fpattending' + rsvpRowCount + '-yes" value="yes" checked="checked"/>',
                '</div>',
                '<div class="rsvp-column">',
                    '<label for="fpattending' + rsvpRowCount + '-no" class="rsvp-label">Decline with regret</label>',
                    '<input type="radio" class="rsvp-input" name="fpattending' + rsvpRowCount + '" id="fpattending' + rsvpRowCount + '-no" value="no"/>',
                '</div>',
            '</div>'].join('');
        $(rsvpRow).insertBefore($("#fprsvp-end"));
    } else if (rsvpRowCount == 6) {
        rsvpRowCount++;
        var contactChris = [
            '<div class="rsvp-row clearfix"></div>',
            '<p>Please contact Chris at (952) 484-5338 if your party contains more than six people. Thanks, and sorry for the inconvenience.</p>'
        ].join('');
        $(contactChris).insertBefore($("#fprsvp-end"));
    } else {
        // do nothing
    }
}

function submitRsvp() {
    $("#submitRsvp").attr("disabled", "disabled");
    $("#rsvpForm").submit();
}

function fpsubmitRsvp() {
    $("#fpsubmitRsvp").attr("disabled", "disabled");
    $("#fprsvpForm").submit();
}